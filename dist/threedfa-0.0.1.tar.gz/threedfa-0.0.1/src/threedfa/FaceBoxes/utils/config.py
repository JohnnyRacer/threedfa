# coding: utf-8

cfg = {
    'name': 'FaceBoxes',
    'min_sizes': [[32, 64, 128], [256], [512]],
    'steps': [32, 64, 128],
    'variance': [0.1, 0.2],
    'clip': False
}
